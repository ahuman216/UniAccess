from flask import Flask, render_template, session, request

app = Flask(__name__)
app.secret_key = 'dev-secret-key'

def get_settings():
    return session.get('settings', {
        'font_size': '1.2rem',
        'contrast': 'high',
        'tts_rate': 1,
        'enable_audio': True,
        'enable_vibration': False
    })

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/caption')
def caption():
    return render_template('caption.html')

@app.route('/read')
def read():
    return render_template('read.html')

@app.route('/vision')
def vision():
    return render_template('vision.html')

@app.route('/alerts', methods=['GET','POST'])
def alerts():
    return render_template('alerts.html')

@app.route('/settings', methods=['GET','POST'])
def settings():
    if request.method == 'POST':
        session['settings'] = request.form.to_dict()
    return render_template('settings.html', settings=get_settings())

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)
